###Relevant Articles:
- [Quick Guide to MapStruct](http://www.baeldung.com/mapstruct)
